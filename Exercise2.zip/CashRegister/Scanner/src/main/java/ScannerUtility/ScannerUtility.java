package ScannerUtility;

public class ScannerUtility {
    public static String getBarcode() {
        return " Scanned 0 ";
    }
}
