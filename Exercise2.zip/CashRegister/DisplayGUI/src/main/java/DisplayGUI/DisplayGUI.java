package DisplayGUI;

import ScannerUtility.ScannerUtility;

import javax.swing.*;
import java.awt.*;

public class DisplayGUI extends JFrame {
    static String Barcode = ScannerUtility.getBarcode();
            public DisplayGUI() {
                super(Barcode);
                setLayout(new FlowLayout());
                add (new JLabel(" Display item " + Barcode));
                setDefaultCloseOperation(EXIT_ON_CLOSE);
                setSize(640, 480);
                setLocationRelativeTo(null);

            }

            public static void main(String[] args) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        new DisplayGUI().setVisible(true);
                    }
                });
            }


}
