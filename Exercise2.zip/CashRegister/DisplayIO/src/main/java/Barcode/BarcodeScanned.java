package Barcode;

import ScannerUtility.ScannerUtility;

public class BarcodeScanned {
    public static void main(String[] args) {
        String barcode = ScannerUtility.getBarcode();
        System.out.print("Item scanned:" + barcode);
    }
}
