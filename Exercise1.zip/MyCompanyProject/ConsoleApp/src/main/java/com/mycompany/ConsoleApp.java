package com.mycompany;

public class ConsoleApp {
    public static void main(String[] args) {
        String appName = CommonUtility.getAppName();
        System.out.print(" Welcome to " + appName);
    }
}
