package com.mycompany;

public class CommonUtility {
    public static String getAppName() {
        return " My Company Project Ultimate Version ";
    }
}
